import { type ModelExtension } from '@stackbit/types';

export const person: ModelExtension = {
    name: 'person',
    labelField: 'name'
};
